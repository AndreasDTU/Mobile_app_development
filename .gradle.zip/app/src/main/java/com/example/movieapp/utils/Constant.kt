package com.example.movieapp.utils

object Constants {
    const val API_KEY = "38fdcd92ab38ddc65ad2b315945281d5"
}